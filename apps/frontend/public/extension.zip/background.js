chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "postJobData") {
    // Get the API key from chrome.storage
    chrome.storage.local.get(["apiKey"], function (result) {
      const apiKey = result.apiKey;

      if (!apiKey) {
        sendResponse({
          success: false,
          error: "API key not found. Please set your API key in the extension.",
        });
        return;
      }

      fetch(
        "https://fellow-dashboard-backend.farhadham2.workers.dev/api/job-posting/extension",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Extension-API-Key": apiKey,
          },
          body: JSON.stringify(message.data),
        }
      )
        .then((response) => response.json())
        .then((data) => {
          if (data.error) {
            // Handle error response from server
            sendResponse({ success: false, error: data.error });
          } else {
            console.log("Response from server:", data);
            sendResponse({ success: true, data });
          }
        })
        .catch((error) => {
          console.error("Error sending data to API:", error);
          sendResponse({ success: false, error: error.message });
        });
    });

    // Return true to indicate that sendResponse will be called asynchronously
    return true;
  }

  if (message.action === "showError" || message.action === "showSuccess") {
    // Forward these messages to the popup if it's open
    chrome.runtime.sendMessage(message);
    return true;
  }
});
