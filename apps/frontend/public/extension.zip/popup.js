document.addEventListener("DOMContentLoaded", () => {
  const apiKeySection = document.getElementById("apiKeySection");
  const actionSection = document.getElementById("actionSection");
  const apiKeyInput = document.getElementById("apiKeyInput");
  const saveApiKeyBtn = document.getElementById("saveApiKeyBtn");
  const startBtn = document.getElementById("startBtn");
  const changeApiKeyBtn = document.getElementById("changeApiKeyBtn");
  const statusElement = document.getElementById("status");

  // Check if API key exists in chrome.storage
  const checkApiKey = () => {
    chrome.storage.local.get(["apiKey"], function (result) {
      if (result.apiKey) {
        // Show action section if API key exists
        apiKeySection.style.display = "none";
        actionSection.style.display = "block";
      } else {
        // Show API key input section if API key doesn't exist
        apiKeySection.style.display = "block";
        actionSection.style.display = "none";
      }
    });
  };

  // Initialize UI based on API key status
  checkApiKey();

  // Listen for error and success messages
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "showError" && message.error) {
      statusElement.textContent = message.error;
      statusElement.className = "error";
    } else if (message.action === "showSuccess" && message.message) {
      statusElement.textContent = message.message;
      statusElement.className = "success";
    }
    return true;
  });

  // Save API key to chrome.storage
  saveApiKeyBtn.addEventListener("click", () => {
    const apiKey = apiKeyInput.value.trim();
    if (apiKey) {
      chrome.storage.local.set({ apiKey: apiKey }, function () {
        statusElement.textContent = "API key saved successfully!";
        statusElement.className = "success";
        checkApiKey(); // Update UI
      });
    } else {
      statusElement.textContent = "Please enter a valid API key.";
      statusElement.className = "error";
    }
  });

  // Change API key button
  changeApiKeyBtn.addEventListener("click", () => {
    // Show API key input section
    apiKeySection.style.display = "block";
    actionSection.style.display = "none";

    // Retrieve current key to show in input
    chrome.storage.local.get(["apiKey"], function (result) {
      apiKeyInput.value = result.apiKey || "";
    });

    statusElement.textContent = "";
    statusElement.className = "";
  });

  // Start button functionality
  startBtn.addEventListener("click", async () => {
    statusElement.textContent = "Processing...";
    statusElement.className = "";

    try {
      let [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      if (tab.url.includes("https://jobs.joinimagine.com/")) {
        chrome.scripting.executeScript(
          {
            target: { tabId: tab.id },
            files: ["content-imagine.js"],
          },
          (results) => {
            if (chrome.runtime.lastError) {
              statusElement.textContent = `Error: ${chrome.runtime.lastError.message}`;
              statusElement.className = "error";
            } else {
              statusElement.textContent = "Loading!";
              statusElement.className = "success";
            }
          }
        );
      } else if (tab.url.includes("https://www.stepstone.de/jobs")) {
        chrome.scripting.executeScript(
          {
            target: { tabId: tab.id },
            files: ["content-stepstone.js"],
          },
          (results) => {
            if (chrome.runtime.lastError) {
              statusElement.textContent = `Error: ${chrome.runtime.lastError.message}`;
              statusElement.className = "error";
            } else {
              statusElement.textContent = "Loading!";
              statusElement.className = "success";
            }
          }
        );
      } else if (tab.url.includes("linkedin.com/jobs/view")) {
        chrome.scripting.executeScript(
          {
            target: { tabId: tab.id },
            files: ["content-linkedin-view.js"],
          },
          (results) => {
            if (chrome.runtime.lastError) {
              statusElement.textContent = `Error: ${chrome.runtime.lastError.message}`;
              statusElement.className = "error";
            } else {
              statusElement.textContent = "Loading!";
              statusElement.className = "success";
            }
          }
        );
      } else if (
        tab.url.includes("linkedin.com/jobs") &&
        !tab.url.includes("linkedin.com/jobs/view")
      ) {
        chrome.scripting.executeScript(
          {
            target: { tabId: tab.id },
            files: ["content-linkedin-list.js"],
          },
          (results) => {
            if (chrome.runtime.lastError) {
              statusElement.textContent = `Error: ${chrome.runtime.lastError.message}`;
              statusElement.className = "error";
            } else {
              statusElement.textContent = "Loading!";
              statusElement.className = "success";
            }
          }
        );
      } else if (tab.url.includes("de.indeed.com")) {
        chrome.scripting.executeScript(
          {
            target: { tabId: tab.id },
            files: ["content-indeed.js"],
          },
          (results) => {
            if (chrome.runtime.lastError) {
              statusElement.textContent = `Error: ${chrome.runtime.lastError.message}`;
              statusElement.className = "error";
            } else {
              statusElement.textContent = "Loading!";
              statusElement.className = "success";
            }
          }
        );
      } else if (tab.url.includes("xing.com/jobs")) {
        chrome.scripting.executeScript(
          {
            target: { tabId: tab.id },
            files: ["content-xing.js"],
          },
          (results) => {
            if (chrome.runtime.lastError) {
              statusElement.textContent = `Error: ${chrome.runtime.lastError.message}`;
              statusElement.className = "error";
            } else {
              statusElement.textContent = "Loading!";
              statusElement.className = "success";
            }
          }
        );
      } else {
        statusElement.textContent = "This extension only works on Jobs pages.";
        statusElement.className = "error";
      }
    } catch (error) {
      statusElement.textContent = `Error: ${error.message}`;
      statusElement.className = "error";
    }
  });
});
